const Message = require("../model/Messenger");

const getMessageData = async (req, res) => {
  try {
    const messages = await Message.find()
      .populate({ path: "from_id", select: "fullname", as: "Sender" })
      .populate({ path: "to_user_id", select: "fullname", as: "Receiver" });

    const formattedData = messages.map((msg) => ({
      id: msg._id,
      from_id: msg.from_id._id,
      messages: msg.messages,
      to_user_id: msg.to_user_id._id,
      createdAt: msg.createdAt,
      updatedAt: msg.updatedAt,
      Sender: {
        fullname: msg.from_id.fullname,
      },
      Receiver: {
        fullname: msg.to_user_id.fullname,
      },
    }));

    res.status(200).json({
      status: 200,
      data: formattedData,
    });
  } catch (error) {
    res.status(500).json({
      status: 500,
      messages: error.message,
    });
  }
};

const sendMessageData = async (req, res) => {
  try {
    const { from_id, to_user_id, messages } = req.body;

    const userMessage = await Message.create({
      from_id,
      to_user_id,
      messages,
    });

    res.status(201).json({
      status: 201,
      message: "Message sent successfull!",
      data: userMessage,
    });
  } catch (error) {
    res.status(500).json({
      status: 500,
      messages: error.message,
    });
  }
};

module.exports = { getMessageData, sendMessageData };
