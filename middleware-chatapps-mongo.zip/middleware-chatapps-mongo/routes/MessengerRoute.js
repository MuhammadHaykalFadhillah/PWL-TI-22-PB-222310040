const express = require("express");
const {
  getMessageData,
  sendMessageData,
} = require("../controllers/MessengersController");
const route = express.Router();

route.get("/", getMessageData);
route.post("/", sendMessageData);

module.exports = route;
